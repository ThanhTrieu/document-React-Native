import React from 'react';

import Contacts from './screens/Contacts';

export default function App() {
  return <Contacts />;
}
