import React from 'react';

import AppNavigator from './routes';

export default function App() {
  return <AppNavigator />;
}
