module.exports = {
  getBlacklistRE() {
    return /1\/|2\//;
  },
};
